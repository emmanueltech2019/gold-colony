# Abraham-Godson-Investment-App-back-end

This is an realtors management portal API